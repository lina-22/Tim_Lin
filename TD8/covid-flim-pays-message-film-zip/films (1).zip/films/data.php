<?php
$films=[[
    "Title"=> "Batman",
    "Year"=> "1989",
    "imdbID"=> "tt0096895",
    "Type"=> "movie",
    "Poster"=> "https://m.media-amazon.com/images/M/MV5BMTYwNjAyODIyMF5BMl5BanBnXkFtZTYwNDMwMDk2._V1_SX300.jpg"
  ],[
    "Title"=> "The Princess Bride",
    "Year"=> "1987",
    "imdbID"=> "tt0093779",
    "Type"=> "movie",
    "Poster"=> "https://m.media-amazon.com/images/M/MV5BMGM4M2Q5N2MtNThkZS00NTc1LTk1NTItNWEyZjJjNDRmNDk5XkEyXkFqcGdeQXVyMjA0MDQ0Mjc@._V1_SX300.jpg"
  ],
  [
    "Title"=> "Princess Mononoke",
    "Year"=> "1997",
    "imdbID"=> "tt0119698",
    "Type"=> "movie",
    "Poster"=> "https://m.media-amazon.com/images/M/MV5BNGIzY2IzODQtNThmMi00ZDE4LWI5YzAtNzNlZTM1ZjYyYjUyXkEyXkFqcGdeQXVyODEzNjM5OTQ@._V1_SX300.jpg"
  ],[
    "Title"=> "Little Miss Sunshine",
    "Year"=> "2006",
    "imdbID"=> "tt0449059",
    "Type"=> "movie",
    "Poster"=> "https://m.media-amazon.com/images/M/MV5BMTgzNTgzODU0NV5BMl5BanBnXkFtZTcwMjEyMjMzMQ@@._V1_SX300.jpg"
  ],[
    "Title"=> "The Little Mermaid",
    "Year"=> "1989",
    "imdbID"=> "tt0097757",
    "Type"=> "movie",
    "Poster"=> "https://m.media-amazon.com/images/M/MV5BN2JlZTBhYTEtZDE3OC00NTA3LTk5NTQtNjg5M2RjODllM2M0XkEyXkFqcGdeQXVyNjk1Njg5NTA@._V1_SX300.jpg"
  ],[
    "Title"=> "Game of Thrones",
    "Year"=> "2011–2019",
    "imdbID"=> "tt0944947",
    "Type"=> "series",
    "Poster"=> "https://m.media-amazon.com/images/M/MV5BYTRiNDQwYzAtMzVlZS00NTI5LWJjYjUtMzkwNTUzMWMxZTllXkEyXkFqcGdeQXVyNDIzMzcwNjc@._V1_SX300.jpg"
  ],[
    "Title"=> "The Expanse",
    "Year"=> "2015–",
    "imdbID"=> "tt3230854",
    "Type"=> "series",
    "Poster"=> "https://m.media-amazon.com/images/M/MV5BMjM4ZTVkODctNGZhNC00NWY5LWJkMjEtYmI1ZDg2Yjg2NDQzXkEyXkFqcGdeQXVyNjcyNjcyMzQ@._V1_SX300.jpg"
  ],[
    "Title"=> "The Grand Budapest Hotel",
    "Year"=> "2014",
    "imdbID"=> "tt2278388",
    "Type"=> "movie",
    "Poster"=> "https://m.media-amazon.com/images/M/MV5BMzM5NjUxOTEyMl5BMl5BanBnXkFtZTgwNjEyMDM0MDE@._V1_SX300.jpg"
  ],[
    "Title"=> "Jurassic Park",
    "Year"=> "1993",
    "imdbID"=> "tt0107290",
    "Type"=> "movie",
    "Poster"=> "https://m.media-amazon.com/images/M/MV5BMjM2MDgxMDg0Nl5BMl5BanBnXkFtZTgwNTM2OTM5NDE@._V1_SX300.jpg"
  ],[
    "Title"=> "In Your Name",
    "Year"=> "2003",
    "imdbID"=> "tt0374271",
    "Type"=> "movie",
    "Poster"=> "https://m.media-amazon.com/images/M/MV5BMjNhN2FiZDUtYmRhYi00MTI5LWEwZGEtZDM3ODA4ZTE1MDMzXkEyXkFqcGdeQXVyODE5NzE3OTE@._V1_SX300.jpg"
  ],[
    "Title"=> "Seven Psychopaths",
    "Year"=> "2012",
    "imdbID"=> "tt1931533",
    "Type"=> "movie",
    "Poster"=> "https://m.media-amazon.com/images/M/MV5BMTgwMzUxMjc0M15BMl5BanBnXkFtZTcwMzQ2MjYyOA@@._V1_SX300.jpg"
  ]
]
?>