
  <footer class=" py-3 bg-secondary text-light">
    <div class="container-fluid">
    <div class="row justify-content-center">
      <p class="col-2 text-center">GRETA MTE 94</p>
    </div>
    </div>

  </footer>
