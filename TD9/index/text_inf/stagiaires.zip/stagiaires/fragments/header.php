<header class="bg-secondary text-light py-2 px-4">
        <h1>Le Site des stagiaires du GRETA</h1>
</header>